<?php get_header(); ?>
<h1>Hello, world!</h1>
<?php get_footer();